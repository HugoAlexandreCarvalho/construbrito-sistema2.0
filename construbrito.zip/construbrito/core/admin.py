from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import Usuario, Produto, Categoria, Cliente, Venda, ItensVenda, ContasAReceber, Pagamento


@admin.register(Usuario)
class UsuarioAdmin(UserAdmin):
    model = Usuario
    list_display = ['email', 'nome', 'is_staff', 'is_active']
    list_filter = ['is_staff', 'is_active']
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Informações Pessoais', {'fields': ('nome',)}),
        ('Permissões', {'fields': ('is_staff', 'is_active', 'is_superuser', 'groups', 'user_permissions')}),
        ('Datas Importantes', {'fields': ('last_login', 'date_joined')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'nome', 'password1', 'password2', 'is_staff', 'is_active'),
        }),
    )
    search_fields = ['email', 'nome']
    ordering = ['email']


@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ['nome', 'descricao']
    search_fields = ['nome']


@admin.register(Produto)
class ProdutoAdmin(admin.ModelAdmin):
    list_display = ['codigo', 'nome', 'categoria', 'preco_venda', 'estoque_atual', 'ativo']
    list_filter = ['categoria', 'ativo']
    search_fields = ['codigo', 'nome']


@admin.register(Cliente)
class ClienteAdmin(admin.ModelAdmin):
    list_display = ['nome', 'cpf_cnpj', 'telefone', 'status_credito', 'limite_credito', 'saldo_devedor']
    list_filter = ['status_credito', 'ativo']
    search_fields = ['nome', 'cpf_cnpj']


class ItensVendaInline(admin.TabularInline):
    model = ItensVenda
    extra = 1


@admin.register(Venda)
class VendaAdmin(admin.ModelAdmin):
    list_display = ['codigo', 'cliente', 'vendedor', 'data_venda', 'status', 'tipo_pagamento', 'total']
    list_filter = ['status', 'tipo_pagamento']
    search_fields = ['codigo', 'cliente__nome']
    inlines = [ItensVendaInline]


@admin.register(ContasAReceber)
class ContasAReceberAdmin(admin.ModelAdmin):
    list_display = ['venda', 'data_vencimento', 'valor_parcela', 'status']
    list_filter = ['status']


@admin.register(Pagamento)
class PagamentoAdmin(admin.ModelAdmin):
    list_display = ['venda', 'tipo', 'status', 'valor_pago', 'data_pagamento']
    list_filter = ['tipo', 'status']
