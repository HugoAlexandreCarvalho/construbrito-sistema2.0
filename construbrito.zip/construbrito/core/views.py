from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.db.models import Sum, F
from .models import Produto, Categoria, Cliente, Venda, ItensVenda, ContasAReceber, Pagamento
from .serializers import (
    ProdutoSerializer, CategoriaSerializer, ClienteSerializer,
    VendaSerializer, ContasAReceberSerializer, PagamentoSerializer
)


class CategoriaViewSet(viewsets.ModelViewSet):
    queryset = Categoria.objects.all()
    serializer_class = CategoriaSerializer
    permission_classes = [IsAuthenticated]


class ProdutoViewSet(viewsets.ModelViewSet):
    queryset = Produto.objects.all()
    serializer_class = ProdutoSerializer
    permission_classes = [IsAuthenticated]

    @action(detail=False, methods=['get'])
    def estoque_baixo(self, request):
        produtos = Produto.objects.filter(estoque_atual__lte=F('estoque_minimo'))
        serializer = self.get_serializer(produtos, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def resumo(self, request):
        total_produtos = Produto.objects.count()
        total_ativos = Produto.objects.filter(ativo=True).count()
        estoque_zero = Produto.objects.filter(estoque_atual=0).count()
        return Response({
            'total_produtos': total_produtos,
            'total_ativos': total_ativos,
            'estoque_zero': estoque_zero,
        })


class ClienteViewSet(viewsets.ModelViewSet):
    queryset = Cliente.objects.all()
    serializer_class = ClienteSerializer
    permission_classes = [IsAuthenticated]

    @action(detail=False, methods=['get'])
    def inadimplentes(self, request):
        clientes = Cliente.objects.filter(status_credito__in=['inadimplente', 'bloqueado'])
        serializer = self.get_serializer(clientes, many=True)
        return Response(serializer.data)


class VendaViewSet(viewsets.ModelViewSet):
    queryset = Venda.objects.all()
    serializer_class = VendaSerializer
    permission_classes = [IsAuthenticated]

    def create(self, request, *args, **kwargs):
        data = request.data
        itens_data = data.pop('itens', [])

        serializer = self.get_serializer(data=data)
        serializer.is_valid(raise_exception=True)
        venda = serializer.save()

        for item_data in itens_data:
            ItensVenda.objects.create(
                venda=venda,
                produto_id=item_data['produto'],
                quantidade=item_data['quantidade'],
                preco_praticado=item_data['preco_praticado']
            )

        venda.calcular_totais()

        # Criar contas a receber se for crediário
        if venda.tipo_pagamento == 'crediario' and venda.parcelas > 1:
            valor_parcela = venda.total / venda.parcelas
            from datetime import datetime, timedelta
            for i in range(venda.parcelas):
                vencimento = datetime.now() + timedelta(days=30 * (i + 1))
                ContasAReceber.objects.create(
                    venda=venda,
                    data_vencimento=vencimento.date(),
                    valor_parcela=valor_parcela
                )

        return Response(self.get_serializer(venda).data, status=status.HTTP_201_CREATED)

    @action(detail=False, methods=['get'])
    def resumo(self, request):
        from django.utils import timezone
        hoje = timezone.now().date()
        vendas_hoje = Venda.objects.filter(data_venda__date=hoje, status='finalizada')
        total_vendas = vendas_hoje.aggregate(total=Sum('total'))['total'] or 0
        quantidade_vendas = vendas_hoje.count()
        return Response({
            'vendas_hoje': quantidade_vendas,
            'total_vendas_hoje': total_vendas,
        })


class ContasAReceberViewSet(viewsets.ModelViewSet):
    queryset = ContasAReceber.objects.all()
    serializer_class = ContasAReceberSerializer
    permission_classes = [IsAuthenticated]

    @action(detail=False, methods=['get'])
    def pendentes(self, request):
        contas = ContasAReceber.objects.filter(status='pendente')
        serializer = self.get_serializer(contas, many=True)
        return Response(serializer.data)


class PagamentoViewSet(viewsets.ModelViewSet):
    queryset = Pagamento.objects.all()
    serializer_class = PagamentoSerializer
    permission_classes = [IsAuthenticated]
