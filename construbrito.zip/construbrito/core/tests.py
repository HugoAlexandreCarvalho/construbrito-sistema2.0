from django.test import TestCase
from django.urls import reverse
from rest_framework.test import APITestCase
from rest_framework import status
from .models import Usuario, Categoria, Produto, Cliente, Venda


class UsuarioModelTest(TestCase):
    def setUp(self):
        self.usuario = Usuario.objects.create_user(
            email='teste@construbrito.com',
            nome='Usuário Teste',
            password='senha123'
        )

    def test_usuario_criacao(self):
        self.assertEqual(self.usuario.email, 'teste@construbrito.com')
        self.assertEqual(self.usuario.nome, 'Usuário Teste')
        self.assertTrue(self.usuario.is_active)

    def test_usuario_str(self):
        self.assertEqual(str(self.usuario), 'Usuário Teste')


class ProdutoModelTest(TestCase):
    def setUp(self):
        self.categoria = Categoria.objects.create(nome='Materiais')
        self.produto = Produto.objects.create(
            codigo='CMT001',
            nome='Cimento 50kg',
            categoria=self.categoria,
            preco_custo=25.00,
            preco_venda=35.00,
            estoque_atual=100
        )

    def test_margem_lucro(self):
        self.assertEqual(self.produto.margem_lucro, 40.0)

    def test_produto_str(self):
        self.assertEqual(str(self.produto), 'CMT001 - Cimento 50kg')


class ClienteModelTest(TestCase):
    def setUp(self):
        self.cliente = Cliente.objects.create(
            nome='Cliente Teste',
            cpf_cnpj='12345678901',
            limite_credito=1000.00,
            saldo_devedor=300.00
        )

    def test_credito_disponivel(self):
        self.assertEqual(self.cliente.credito_disponivel, 700.00)


class APITest(APITestCase):
    def setUp(self):
        self.usuario = Usuario.objects.create_user(
            email='api@construbrito.com',
            nome='API User',
            password='testpass'
        )
        self.client.force_authenticate(user=self.usuario)

    def test_lista_produtos(self):
        url = reverse('produto-list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
