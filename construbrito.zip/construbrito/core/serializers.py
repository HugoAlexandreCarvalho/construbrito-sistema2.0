from rest_framework import serializers
from .models import Usuario, Produto, Categoria, Cliente, Venda, ItensVenda, ContasAReceber, Pagamento


class UsuarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Usuario
        fields = ['id', 'email', 'nome', 'is_staff', 'is_active']


class CategoriaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Categoria
        fields = '__all__'


class ProdutoSerializer(serializers.ModelSerializer):
    categoria_nome = serializers.CharField(source='categoria.nome', read_only=True)
    margem_lucro = serializers.FloatField(read_only=True)

    class Meta:
        model = Produto
        fields = '__all__'


class ClienteSerializer(serializers.ModelSerializer):
    credito_disponivel = serializers.FloatField(read_only=True)

    class Meta:
        model = Cliente
        fields = '__all__'


class ItensVendaSerializer(serializers.ModelSerializer):
    produto_nome = serializers.CharField(source='produto.nome', read_only=True)

    class Meta:
        model = ItensVenda
        fields = '__all__'


class VendaSerializer(serializers.ModelSerializer):
    itens = ItensVendaSerializer(many=True, read_only=True)
    cliente_nome = serializers.CharField(source='cliente.nome', read_only=True)
    vendedor_nome = serializers.CharField(source='vendedor.nome', read_only=True)

    class Meta:
        model = Venda
        fields = '__all__'


class ContasAReceberSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContasAReceber
        fields = '__all__'


class PagamentoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Pagamento
        fields = '__all__'
