# ConstruBrito - Sistema de Gestão Comercial

## Requisitos
- Python 3.10+
- pip

## Instalação

1. Crie e ative o ambiente virtual:
```bash
python -m venv venv
venv\Scripts\activate  # Windows
source venv/bin/activate  # Linux/Mac
```

2. Instale as dependências:
```bash
pip install -r requirements.txt
```

3. Configure o banco de dados (SQLite para testes):
```bash
copy .env.example .env  # Windows
cp .env.example .env    # Linux/Mac
```

4. Execute as migrações:
```bash
python manage.py migrate
```

5. Crie um superusuário:
```bash
python manage.py createsuperuser
```

6. Inicie o servidor:
```bash
python manage.py runserver
```

Acesse: http://127.0.0.1:8000/
Admin: http://127.0.0.1:8000/admin/
API: http://127.0.0.1:8000/api/
